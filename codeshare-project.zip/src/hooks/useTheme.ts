import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'

type Theme = 'light' | 'dark'

export const useTheme = () => {
  const { user, profile } = useAuth()
  const [theme, setTheme] = useState<Theme>('light')
  const [loading, setLoading] = useState(true)

  // Initialize theme on mount (only in browser)
  useEffect(() => {
    if (typeof window !== 'undefined') {
      initializeTheme()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, profile])

  const initializeTheme = async () => {
    try {
      let savedTheme: Theme = 'light'

      if (user && profile?.theme) {
        savedTheme = profile.theme as Theme
      } else {
        const localTheme = typeof window !== 'undefined'
          ? (localStorage.getItem('theme') as Theme)
          : null

        if (localTheme && (localTheme === 'light' || localTheme === 'dark')) {
          savedTheme = localTheme
        }
      }

      applyTheme(savedTheme)
      setTheme(savedTheme)
    } catch (error) {
      console.error('Error initializing theme:', error)
      applyTheme('light')
      setTheme('light')
    } finally {
      setLoading(false)
    }
  }

  const applyTheme = (newTheme: Theme) => {
    if (typeof document !== 'undefined') {
      const html = document.documentElement

      if (newTheme === 'dark') {
        html.classList.add('dark')
      } else {
        html.classList.remove('dark')
      }
    }

    if (typeof window !== 'undefined') {
      localStorage.setItem('theme', newTheme)
    }
  }

  const toggleTheme = async () => {
    const newTheme: Theme = theme === 'light' ? 'dark' : 'light'

    try {
      applyTheme(newTheme)
      setTheme(newTheme)

      if (user) {
        const { error } = await supabase
          .from('profiles')
          .update({ theme: newTheme })
          .eq('id', user.id)

        if (error) {
          console.error('Error saving theme preference:', error)
        }
      }
    } catch (error) {
      console.error('Error toggling theme:', error)
      applyTheme(theme)
      setTheme(theme)
    }
  }

  const setThemePreference = async (newTheme: Theme) => {
    try {
      applyTheme(newTheme)
      setTheme(newTheme)

      if (user) {
        const { error } = await supabase
          .from('profiles')
          .update({ theme: newTheme })
          .eq('id', user.id)

        if (error) {
          console.error('Error saving theme preference:', error)
        }
      }
    } catch (error) {
      console.error('Error setting theme preference:', error)
      applyTheme(theme)
      setTheme(theme)
    }
  }

  return {
    theme,
    toggleTheme,
    setThemePreference,
    loading
  }
}
