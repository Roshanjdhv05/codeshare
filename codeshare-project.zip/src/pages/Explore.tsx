import React, { useState, useEffect } from 'react'
import { Users, UserPlus, UserCheck, User } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { Database } from '../lib/database.types'
import { useAuth } from '../contexts/AuthContext'
import { Link } from 'react-router-dom'
import { SearchBar } from '../components/SearchBar'
import { useDebounce } from '../hooks/useDebounce'

type Profile = Database['public']['Tables']['profiles']['Row']
type ProfileWithStats = Profile & {
  followers_count: number
  following_count: number
  public_folders_count: number
  is_following: boolean
}

const Explore: React.FC = () => {
  const { user } = useAuth()
  const [profiles, setProfiles] = useState<ProfileWithStats[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [followingUsers, setFollowingUsers] = useState<Set<string>>(new Set())
  const [filter, setFilter] = useState<'newest' | 'followers' | 'projects'>('newest')

  const debouncedSearchTerm = useDebounce(searchTerm, 400)

  useEffect(() => {
    fetchProfiles()
    if (user) fetchFollowingUsers()
  }, [user])

  useEffect(() => {
    if (debouncedSearchTerm.trim()) searchProfiles(debouncedSearchTerm)
    else fetchProfiles()
  }, [debouncedSearchTerm, filter])

  const fetchProfiles = async () => {
    setLoading(true)
    try {
      const { data: profilesData, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50)

      if (error) {
        console.error('Error fetching profiles:', error)
        return
      }

      const profilesWithStats = await Promise.all(
        profilesData.map(async (profile) => {
          const { data: stats } = await supabase.rpc('get_user_stats', {
            user_uuid: profile.id
          })

          const statsData = stats?.[0] ?? {
            followers_count: 0,
            following_count: 0,
            public_folders_count: 0
          }

          return {
            ...profile,
            ...statsData,
            is_following: followingUsers.has(profile.id)
          }
        })
      )

      const sortedProfiles = sortProfiles(profilesWithStats, filter)
      setProfiles(sortedProfiles)
    } catch (error) {
      console.error('Error fetching profiles:', error)
    } finally {
      setLoading(false)
    }
  }

  const searchProfiles = async (term: string) => {
    setLoading(true)
    try {
      const { data: profilesData, error } = await supabase
        .from('profiles')
        .select('*')
        .or(`username.ilike.%${term}%,full_name.ilike.%${term}%`)
        .order('created_at', { ascending: false })
        .limit(50)

      if (error) {
        console.error('Error searching profiles:', error)
        return
      }

      const profilesWithStats = await Promise.all(
        profilesData.map(async (profile) => {
          const { data: stats } = await supabase.rpc('get_user_stats', {
            user_uuid: profile.id
          })

          const statsData = stats?.[0] ?? {
            followers_count: 0,
            following_count: 0,
            public_folders_count: 0
          }

          return {
            ...profile,
            ...statsData,
            is_following: followingUsers.has(profile.id)
          }
        })
      )

      const sortedProfiles = sortProfiles(profilesWithStats, filter)
      setProfiles(sortedProfiles)
    } catch (error) {
      console.error('Error searching profiles:', error)
    } finally {
      setLoading(false)
    }
  }

  const sortProfiles = (profiles: ProfileWithStats[], filterType: typeof filter) => {
    if (filterType === 'followers') {
      return [...profiles].sort((a, b) => b.followers_count - a.followers_count)
    }
    if (filterType === 'projects') {
      return [...profiles].sort((a, b) => b.public_folders_count - a.public_folders_count)
    }
    // default = newest
    return [...profiles].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    )
  }

  const fetchFollowingUsers = async () => {
    if (!user) return
    try {
      const { data, error } = await supabase
        .from('user_followers')
        .select('following_id')
        .eq('follower_id', user.id)

      if (error) {
        console.error('Error fetching following users:', error)
        return
      }

      setFollowingUsers(new Set(data.map((d) => d.following_id)))
    } catch (error) {
      console.error('Error fetching following users:', error)
    }
  }

  const handleFollow = async (profileId: string) => {
    if (!user) return

    try {
      const isFollowing = followingUsers.has(profileId)

      if (isFollowing) {
        const { error } = await supabase
          .from('user_followers')
          .delete()
          .eq('follower_id', user.id)
          .eq('following_id', profileId)

        if (error) throw error

        setFollowingUsers(prev => {
          const newSet = new Set(prev)
          newSet.delete(profileId)
          return newSet
        })
      } else {
        const { error } = await supabase
          .from('user_followers')
          .insert([{ follower_id: user.id, following_id: profileId }])

        if (error) throw error

        setFollowingUsers(prev => new Set(prev).add(profileId))
      }

      setProfiles(prev => {
        const updated = prev.map(profile =>
          profile.id === profileId
            ? {
                ...profile,
                is_following: !isFollowing,
                followers_count: isFollowing
                  ? profile.followers_count - 1
                  : profile.followers_count + 1
              }
            : profile
        )
        return sortProfiles(updated, filter)
      })
    } catch (error) {
      console.error('Error toggling follow:', error)
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 bg-gray-900 text-gray-100 min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Explore Developers</h1>
        <p className="mt-2 text-gray-400">Discover and connect with developers in the community</p>
      </div>

      {/* Search + Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <SearchBar value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />

        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
          className="bg-gray-800 text-gray-100 border border-gray-700 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="newest">Newest</option>
          <option value="followers">Most Followers</option>
          <option value="projects">Most Projects</option>
        </select>
      </div>

      {/* Profiles Grid */}
      {loading ? (
        <div className="animate-pulse">
          <div className="h-8 bg-gray-700 rounded mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-gray-800 rounded-lg h-48"></div>
            ))}
          </div>
        </div>
      ) : profiles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {profiles.map(profile => (
            <div
              key={profile.id}
              className="bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 overflow-hidden"
            >
              <div className="p-6">
                {/* Profile Header */}
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-xl font-bold">
                      {profile.username[0].toUpperCase()}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <Link
                      to={`/profile/${profile.username}`}
                      className="text-lg font-semibold text-gray-100 hover:text-blue-400 transition-colors truncate block"
                    >
                      {profile.full_name || profile.username}
                    </Link>
                    <p className="text-gray-400 text-sm">@{profile.username}</p>
                  </div>
                </div>

                {/* Bio */}
                {profile.bio && (
                  <p className="text-gray-300 text-sm mb-4 line-clamp-3">{profile.bio}</p>
                )}

                {/* Stats */}
                <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                  <div className="flex items-center gap-4">
                    <span>
                      <strong>{profile.followers_count}</strong> followers
                    </span>
                    <span>
                      <strong>{profile.public_folders_count}</strong> projects
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3">
                  <Link
                    to={`/profile/${profile.username}`}
                    className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-gray-600 text-gray-100 rounded-md hover:bg-gray-700 transition-colors text-sm"
                  >
                    <User className="h-4 w-4 mr-2" />
                    View Profile
                  </Link>

                  {user && user.id !== profile.id && (
                    <button
                      onClick={() => handleFollow(profile.id)}
                      className={`inline-flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        followingUsers.has(profile.id)
                          ? 'bg-gray-700 text-gray-100 hover:bg-gray-600'
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                      }`}
                    >
                      {followingUsers.has(profile.id) ? (
                        <>
                          <UserCheck className="h-4 w-4 mr-2" />
                          Following
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-4 w-4 mr-2" />
                          Follow
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Users className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-white mb-2">No users found</h3>
          <p className="text-gray-500">
            {searchTerm ? 'Try adjusting your search terms.' : 'No users to display at the moment.'}
          </p>
        </div>
      )}
    </div>
  )
}

export default Explore
